import Card from 'react-bootstrap/Card';
import Col from 'react-bootstrap/Col';
import Row from 'react-bootstrap/Row';

function Contacto() {
  // Declaración de los participantes con sus respectivas imágenes y descripciones
  const participantes = [
    {
      nombre: "Juan Carlos Arias González",
      codigo: "2225007",
      descripcion: "Realizó la parte de registros de vuelo, dónde implementó diversos tipos de elementos, funciones, estilos y etiquetas además también implementó el login.",
      imagen: "ruta_de_imagen_de_carlos",
    },
    {
      nombre: "Juan Diego Herrera Cáceres",
      codigo: "2151316",
      descripcion: "Realizó toda la parte del menú principal, dónde implementó varias funciones, elementos, etiquetas y componentes (entre ellos el más destacado es el iframe).",
      imagen: "ruta_de_imagen_de_diego",
    },
    {
      nombre: "Johany Moreno Moreno",
      codigo: "2215512",
      descripcion: "Realizó la parte de vuelos y destinos, dónde implementó diferentes elementos, funciones y componentes (acordeones y listas).",
      imagen: "ruta_de_imagen_de_johany",
    },
    {
      nombre: "Jenifer Karina Alfonso",
      codigo: "2215109",
      descripcion: "Realizó la parte de contactos, dónde implementó distintas funciones, herramientas, estilos y componentes (tarjetas).",
      imagen: "ruta_de_imagen_de_karina",
    },
  ];

  return (
    <Row xs={1} md={2} className="g-4" style={{ backgroundColor: "#123624" }}>
      {participantes.map((participante, idx) => (
        <Col key={idx}>
          <Card
            style={{
              borderColor: "#000000",
              borderRadius: "3%",
              borderWidth: "1px",
              backgroundColor: idx % 2 === 0 ? "#4f5d57" : "white",
            }}
          >
            <Card.Img
              variant="top"
              src={participante.imagen}
              style={{
                height: "50%",
                width: "50%",
                alignContent: "center",
                margin: "5% 25%",
                transition: "filter 0.1s ease",
                filter: "grayscale(0%)",
              }}
              onMouseOver={(e) => (e.currentTarget.style.filter = "grayscale(100%)")}
              onMouseOut={(e) => (e.currentTarget.style.filter = "grayscale(0%)")}
            />
            <Card.Body
              style={{
                backgroundColor: "gray",
                color: "white",
              }}
            >
              <Card.Title
                style={{
                  textAlign: "center",
                  color: "white",
                  fontSize: "22px",
                }}
              >
                <b>{`${participante.nombre} - ${participante.codigo}`}</b>
              </Card.Title>
              <Card.Text
                style={{
                  textAlign: "center",
                  color: "white",
                  fontSize: "16px",
                }}
              >
                <i>{participante.descripcion}</i>
              </Card.Text>
            </Card.Body>
          </Card>
        </Col>
      ))}
    </Row>
  );
}

export default Contacto;

