# Proyecto Niubus-Aire
Proyecto sobre Aereolinea Comercial realizada en REACT.

## Colaboradores Proyecto (100% - Participativos )
 Jenifer Karina Alfonso- 2215109||
 Juan Carlos Arias González- 2225007||
 Juan Diego Herrera Cáceres- 2151316||
 Johany Moreno Moreno- 2215512 ||

Primero
## Base de datos - Use Xampp

### Start Apache | Start MySQL -> admin 
### `Crear Usuario` -> host: "localhost", user: "admin", password: "123456789", database: "niubus" (Todos los Privilegios globales)
### `Import DB` -> use niubus.sql (asegurese de que la DB se asociará al usuario creado) -> ir al servidor (Servidor: 127.0.0.1) -> cuentas de usario (user 'admin') -> Bases de datos  -> "Añadir privilegios a la o las base de datos siguientes:" - "niubus" (continuar -> seleccionar todo -> continuar) 
### `Datos predeterminados BD` -> use llenado.sql (seccion sql, ejecute insert por separado), importe el sql de llenado, igual como se importó el de niubus

Modulos/librerias a descargar para el funcionamiento del proyecto. (sobre la carpeta client en su terminal de comandos)

### `Instalar modulos de REACT`
#### npm install react react-dom 
### `Instalar react-bootstrap`
#### npm install react-bootstrap bootstrap
### `Ejecutar Proyecto`
#### npm start


## Instrucciones para Correcta Ejecución - Server (BACKEND)
Asegurese de estar en la ruta correcta (sobre la carpeta client en su terminal de comandos)
### `Instalar modulos`
#### npm install
#### npm install mysql express
#### npm install cors
### `Ejecutar Server`
#### node index.js

Despues de haber cargado el backend y cargado la pagina
## Login
### `Credenciales`
#### user : 'usuario'
#### password : 'contraseña'
### `Nota`
#### La pestaña Reservas es de tipo privada, por lo que necesita del login para tener acceso a la misma. 





